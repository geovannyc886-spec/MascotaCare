package com.example.mascotacare.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val PETS = "pets"
    const val ADD_PET = "add_pet"
    const val VACCINES = "vaccines"
    const val APPOINTMENT = "appointment"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    // Barra inferior: 0 = Inicio, 1 = Mascotas, 2 = Citas, 3 = Perfil (aún sin pantalla)
    val goToTab: (Int) -> Unit = { index ->
        val route = when (index) {
            0 -> Routes.HOME
            1 -> Routes.PETS
            2 -> Routes.VACCINES
            else -> null
        }
        if (route != null) {
            navController.navigate(route) {
                popUpTo(Routes.HOME) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
    }

    NavHost(navController = navController, startDestination = Routes.LOGIN) {
        composable(Routes.LOGIN) {
            LoginScreen(
                onLoginClick = { _, _ ->
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                onTabSelected = goToTab,
                onScheduleClick = { navController.navigate(Routes.APPOINTMENT) },
                onAddPetClick = { navController.navigate(Routes.ADD_PET) },
                onViewDetailClick = { goToTab(2) }
            )
        }
        composable(Routes.PETS) {
            PetsScreen(
                onTabSelected = goToTab,
                onAddPetClick = { navController.navigate(Routes.ADD_PET) }
            )
        }
        composable(Routes.ADD_PET) {
            AddPetScreen(
                onBack = { navController.popBackStack() },
                onSave = { navController.popBackStack() },
                onTabSelected = goToTab
            )
        }
        composable(Routes.VACCINES) {
            VaccinesScreen(
                onTabSelected = goToTab,
                onAddClick = { navController.navigate(Routes.APPOINTMENT) }
            )
        }
        composable(Routes.APPOINTMENT) {
            AppointmentScreen(
                onBack = { navController.popBackStack() },
                onDone = { navController.popBackStack() },
                onTabSelected = goToTab
            )
        }
    }
}
