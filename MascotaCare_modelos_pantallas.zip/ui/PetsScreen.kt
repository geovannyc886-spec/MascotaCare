package com.example.mascotacare.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mascotacare.R
import com.example.mascotacare.domain.model.Mascota
import com.example.mascotacare.ui.theme.MascotaCareTheme

private data class PetItem(
    val id: Int,
    val name: String,
    val age: String,
    val info: String,
    val photo: Int
)

private data class PetsNavItem(@StringRes val label: Int, val icon: ImageVector)

private val petsNavItems = listOf(
    PetsNavItem(R.string.nav_home, Icons.Outlined.FavoriteBorder),
    PetsNavItem(R.string.nav_pets, Icons.Outlined.AccountCircle),
    PetsNavItem(R.string.nav_appointments, Icons.Outlined.CalendarMonth),
    PetsNavItem(R.string.nav_profile, Icons.Outlined.PersonOutline)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetsScreen(
    mascotas: List<Mascota> = emptyList(),
    onTabSelected: (Int) -> Unit = {},
    onAddPetClick: () -> Unit = {},
    onPetClick: (String) -> Unit = {}
) {
    var query by rememberSaveable { mutableStateOf("") }
    val colors = MaterialTheme.colorScheme
    val petItems = mascotas.map { mascota ->
        PetItem(
            id = mascota.id,
            name = mascota.nombre,
            age = mascota.fechaNacimiento?.let(::formatPetAge)
                ?: stringResource(R.string.pet_age_unknown),
            info = listOf(mascota.especie, mascota.raza)
                .filter(String::isNotBlank)
                .joinToString(" · "),
            photo = petImageFor(mascota.nombre)
        )
    }
    val visiblePets = petItems.filter { it.name.contains(query.trim(), ignoreCase = true) }

    Scaffold(
        containerColor = colors.background,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.home_my_pets), fontWeight = FontWeight.Medium) },
                navigationIcon = {
                    Icon(
                        Icons.Outlined.AccountCircle,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.padding(start = 16.dp, end = 8.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background)
            )
        },
        bottomBar = {
            NavigationBar {
                petsNavItems.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = index == 1,
                        onClick = { onTabSelected(index) },
                        icon = { Icon(item.icon, contentDescription = stringResource(item.label)) },
                        label = { Text(stringResource(item.label)) }
                    )
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddPetClick,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text(stringResource(R.string.home_add), fontWeight = FontWeight.Bold) },
                containerColor = colors.primaryContainer,
                contentColor = colors.onPrimaryContainer
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(stringResource(R.string.pets_search)) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = colors.primary) },
                    singleLine = true,
                    shape = CircleShape,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = colors.surfaceVariant,
                        unfocusedContainerColor = colors.surfaceVariant,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        stringResource(R.string.pets_family),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        stringResource(R.string.pets_count, visiblePets.size),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant
                    )
                }
            }

            items(visiblePets, key = { it.id }) { pet ->
                PetCard(pet = pet, onClick = { onPetClick(pet.name) })
            }

            if (visiblePets.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.pets_empty),
                        color = colors.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp)
                    )
                }
            }

            item { Spacer(Modifier.height(72.dp)) }
        }
    }
}

@Composable
private fun PetCard(pet: PetItem, onClick: () -> Unit) {
    val colors = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = colors.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(pet.photo),
                contentDescription = stringResource(R.string.pets_photo_desc, pet.name),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
            )
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(pet.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                    Text(
                        pet.age,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurfaceVariant
                    )
                }
                Text(
                    pet.info,
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant
                )
                Text(
                    stringResource(R.string.pets_saved_status),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.primary,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = colors.onSurfaceVariant)
        }
    }
}

private fun petImageFor(name: String): Int = when (name.lowercase()) {
    "bruno" -> R.drawable.pet_bruno
    "luna" -> R.drawable.pet_luna
    "max" -> R.drawable.pet_max
    "nala" -> R.drawable.pet_nala
    else -> R.drawable.ic_paw
}

private fun formatPetAge(birthMillis: Long): String {
    val months = ((System.currentTimeMillis() - birthMillis).coerceAtLeast(0L) /
        (30L * 24 * 60 * 60 * 1000)).toInt()
    return if (months >= 12) "${months / 12} años" else "$months meses"
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun PetsScreenPreview() {
    MascotaCareTheme { PetsScreen() }
}
