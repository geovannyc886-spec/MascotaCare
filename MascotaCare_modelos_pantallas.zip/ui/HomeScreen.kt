package com.example.mascotacare.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mascotacare.domain.model.Mascota
import com.example.mascotacare.ui.theme.MascotaCareTheme

private data class Pet(val name: String, val color: Color)
private data class Reminder(
    val title: String,
    val subtitle: String,
    val category: String,
    val icon: ImageVector,
)
private data class NavItem(val label: String, val icon: ImageVector)

private val navItems = listOf(
    NavItem("Inicio", Icons.Filled.Home),
    NavItem("Mascotas", Icons.Filled.Pets),
    NavItem("Citas", Icons.Filled.CalendarMonth),
    NavItem("Perfil", Icons.Filled.Person)
)

private val filters = listOf("Todo", "Vacunas", "Citas", "Salud")

private val reminders = listOf(
    Reminder("Desparasitar a Luna", "Mañana · 8:00 a. m.", "Salud", Icons.Filled.Vaccines),
    Reminder("Consulta de Max", "28 oct · 5:00 p. m.", "Citas", Icons.Filled.CalendarMonth),
    Reminder("Vacuna triple de Bruno", "12 nov · 9:00 a. m.", "Vacunas", Icons.Filled.Vaccines)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    userName: String = "Ana",
    mascotas: List<Mascota> = emptyList(),
    onTabSelected: (Int) -> Unit = {},
    onScheduleClick: () -> Unit = {},
    onAddPetClick: () -> Unit = {},
    onViewDetailClick: () -> Unit = {}
) {
    var selectedFilter by rememberSaveable { mutableIntStateOf(0) }

    val visibleReminders = if (selectedFilter == 0) reminders
    else reminders.filter { it.category == filters[selectedFilter] }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Hola, $userName", fontWeight = FontWeight.Bold) },
                actions = {
                    Box(
                        modifier = Modifier
                            .padding(end = 16.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            userName.first().uppercase(),
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar {
                navItems.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = index == 0,
                        onClick = { onTabSelected(index) },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onScheduleClick,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Agendar cita")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { NextAppointmentCard(onViewDetailClick = onViewDetailClick) }

            item { SectionTitle("Mis mascotas") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    items(mascotas) { mascota ->
                        PetAvatar(
                            Pet(
                                mascota.nombre,
                                when (mascota.id % 3) {
                                    0 -> MaterialTheme.colorScheme.primaryContainer
                                    1 -> MaterialTheme.colorScheme.secondaryContainer
                                    else -> MaterialTheme.colorScheme.tertiaryContainer
                                }
                            )
                        )
                    }
                    item { AddPetButton(onClick = onAddPetClick) }
                }
            }

            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filters.size) { i ->
                        FilterChip(
                            selected = selectedFilter == i,
                            onClick = { selectedFilter = i },
                            label = { Text(filters[i]) },
                            leadingIcon = if (selectedFilter == i) {
                                { Icon(Icons.Filled.Check, null, Modifier.size(18.dp)) }
                            } else null
                        )
                    }
                }
            }

            item { SectionTitle("Recordatorios") }
            items(visibleReminders) { r -> ReminderItem(r) }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun NextAppointmentCard(onViewDetailClick: () -> Unit = {}) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Próxima cita", style = MaterialTheme.typography.labelLarge)
                Text(
                    "Vacuna antirrábica",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text("Bruno · 25 oct · 10:30 a. m.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onViewDetailClick) { Text("Ver detalle") }
            }
            Icon(
                Icons.Filled.Pets,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(72.dp)
            )
        }
    }
}

@Composable
private fun PetAvatar(pet: Pet) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(pet.color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                pet.name.first().toString(),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(pet.name, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun AddPetButton(onClick: () -> Unit = {}) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            onClick = onClick,
            shape = CircleShape,
            color = Color.Transparent,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),modifier = Modifier.size(60.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Filled.Add,
                    contentDescription = "Agregar mascota",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("Agregar", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ReminderItem(reminder: Reminder) {
    ListItem(
        headlineContent = { Text(reminder.title, fontWeight = FontWeight.Bold) },
        supportingContent = { Text(reminder.subtitle) },
        leadingContent = {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.secondaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    reminder.icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
            }
        },
        trailingContent = {
            Icon(Icons.Filled.ChevronRight, contentDescription = null)
        },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun HomeScreenPreview() {
    MascotaCareTheme { HomeScreen() }
}
