package com.example.mascotacare.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mascotacare.R
import com.example.mascotacare.ui.theme.MascotaCareTheme
import java.util.Calendar

private enum class VaccineStatus { PENDING, APPLIED }

private data class Vaccine(
    @StringRes val name: Int,
    @StringRes val detail: Int,
    val status: VaccineStatus
)

private val petNames = listOf("Bruno", "Luna", "Max")

private val vaccinesByPet = listOf(
    listOf(
        Vaccine(R.string.vacc_rabies, R.string.vdetail_bruno_1, VaccineStatus.PENDING),
        Vaccine(R.string.vacc_polyvalent, R.string.vdetail_bruno_2, VaccineStatus.APPLIED)
    ),
    listOf(
        Vaccine(R.string.vacc_feline_triple, R.string.vdetail_luna_1, VaccineStatus.PENDING),
        Vaccine(R.string.vacc_rabies, R.string.vdetail_luna_2, VaccineStatus.APPLIED)
    ),
    listOf(
        Vaccine(R.string.vacc_polyvalent, R.string.vdetail_max_1, VaccineStatus.PENDING),
        Vaccine(R.string.vacc_rabies, R.string.vdetail_max_2, VaccineStatus.APPLIED)
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaccinesScreen(
    onTabSelected: (Int) -> Unit = {},
    onAddClick: () -> Unit = {}
) {
    val colors = MaterialTheme.colorScheme
    var selectedPet by rememberSaveable { mutableIntStateOf(0) }

    // Mes que se está viendo y día seleccionado (octubre 2026, día 25)
    var year by rememberSaveable { mutableIntStateOf(2026) }
    var month by rememberSaveable { mutableIntStateOf(9) } // 0 = enero
    var selYear by rememberSaveable { mutableIntStateOf(2026) }
    var selMonth by rememberSaveable { mutableIntStateOf(9) }
    var selDay by rememberSaveable { mutableIntStateOf(25) }

    val vaccines = vaccinesByPet[selectedPet]

    Scaffold(
        containerColor = colors.background,
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.vaccines_title)) },
                navigationIcon = {
                    Icon(
                        Icons.Filled.CalendarMonth,
                        contentDescription = null,
                        tint = colors.primary,
                        modifier = Modifier.padding(start = 16.dp, end = 8.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background)
            )
        },
        bottomBar = { MascotaNavigationBar(selectedIndex = 2, onTabSelected = onTabSelected) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddClick,
                containerColor = colors.primaryContainer,
                contentColor = colors.onPrimaryContainer
            ) {
                Icon(Icons.Filled.Add, contentDescription = stringResource(R.string.home_schedule_appointment))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = dimensionResource(R.dimen.home_padding), vertical = dimensionResource(R.dimen.spacing_small)),
            verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.spacing_medium))
        ) {
            // Selector de mascota
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                petNames.forEachIndexed { index, name ->
                    SegmentedButton(
                        selected = selectedPet == index,
                        onClick = { selectedPet = index },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = petNames.size),
                        colors = SegmentedButtonDefaults.colors(
                            activeContainerColor = colors.primaryContainer,
                            activeContentColor = colors.onPrimaryContainer
                        )
                    ) {
                        Text(name, fontWeight = FontWeight.Bold)
                    }
                }
            }

            CalendarCard(
                year = year,
                month = month,
                selYear = selYear,
                selMonth = selMonth,
                selDay = selDay,
                onPrev = {
                    if (month == 0) { month = 11; year-- } else month--
                },
                onNext = {
                    if (month == 11) { month = 0; year++ } else month++
                },
                onSelectDay = { day -> selYear = year; selMonth = month; selDay = day }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    stringResource(R.string.vaccines_of, petNames[selectedPet]),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    stringResource(R.string.vaccines_records, vaccines.size),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant
                )
            }

            vaccines.forEach { VaccineCard(it) }

            Spacer(Modifier.height(72.dp)) // espacio para el botón flotante
        }
    }
}

@Composable
private fun CalendarCard(
    year: Int,
    month: Int,
    selYear: Int,
    selMonth: Int,
    selDay: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onSelectDay: (Int) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val months = stringArrayResource(R.array.months)
    val weekdays = stringArrayResource(R.array.weekdays)

    // Calcula cuántos días tiene el mes y en qué columna empieza (lunes = 0)
    val cal = Calendar.getInstance().apply { clear(); set(year, month, 1) }
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val offset = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val weeks = (offset + daysInMonth + 6) / 7

    Card(
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = colors.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onPrev) {
                    Icon(Icons.Filled.ChevronLeft, stringResource(R.string.calendar_prev), tint = colors.primary)
                }
                Text(
                    text = stringResource(R.string.calendar_month_year, months[month], year),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium
                )
                IconButton(onClick = onNext) {
                    Icon(Icons.Filled.ChevronRight, stringResource(R.string.calendar_next), tint = colors.primary)
                }
            }

            Row(Modifier.fillMaxWidth()) {
                weekdays.forEach { d ->
                    Text(
                        d,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelMedium,
                        color = colors.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(4.dp))

            for (week in 0 until weeks) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0 until 7) {
                        val day = week * 7 + col - offset + 1
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            if (day in 1..daysInMonth) {
                                val isSelected = day == selDay && month == selMonth && year == selYear
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) colors.primary else Color.Transparent)
                                        .clickable { onSelectDay(day) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        day.toString(),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isSelected) colors.onPrimary else colors.onSurface,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VaccineCard(vaccine: Vaccine) {
    val colors = MaterialTheme.colorScheme
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = colors.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(vaccine.name), style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                Text(
                    stringResource(vaccine.detail),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.onSurfaceVariant
                )
            }
            Spacer(Modifier.width(8.dp))
            StatusChip(vaccine.status)
        }
    }
}

@Composable
private fun StatusChip(status: VaccineStatus) {
    val colors = MaterialTheme.colorScheme
    if (status == VaccineStatus.PENDING) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = colors.background,
            border = BorderStroke(1.dp, colors.outlineVariant)
        ) {
            Text(
                stringResource(R.string.vaccine_pending),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                style = MaterialTheme.typography.labelLarge
            )
        }
    } else {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = colors.primaryContainer
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Check, null, Modifier.size(18.dp), tint = colors.onPrimaryContainer)
                Spacer(Modifier.width(6.dp))
                Text(
                    stringResource(R.string.vaccine_applied),
                    style = MaterialTheme.typography.labelLarge,
                    color = colors.onPrimaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun VaccinesScreenPreview() {
    MascotaCareTheme { VaccinesScreen() }
}
